package mx.edu.ittepic.ladm_u4_tarea1_contentproviderskotlin

import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.CallLog
import android.widget.SimpleCursorAdapter
import androidx.core.app.ActivityCompat
import kotlinx.android.synthetic.main.activity_llamadas.*

class LlamadasActivity : AppCompatActivity() {

    var siPermisoLlamadas = 707
    var llamadas = listOf<String>(CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.TYPE).toTypedArray()
    //1.- Llamdas entrantes
    //2.- Llamadas salientes
    //3.- Llamadas perdidas
    //4.- Llamdas Voice mail
    //5.- Llamdas rechazadas
    //6.- Numeros Bloqueados
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_llamadas)
        //Verificar si tiene permiso
        if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED){
            //Si no lo tiene entonces otorgar permiso
            ActivityCompat.requestPermissions(this, Array(1){
                android.Manifest.permission.READ_CALL_LOG
            }, siPermisoLlamadas)
        }else{
            registroLlamadas()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == siPermisoLlamadas){
            registroLlamadas()
        }
    }

    fun registroLlamadas(){
        var datos = listOf<String>(CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.TYPE).toTypedArray()
        var tipo = "3"
        var datosEnPantalla = intArrayOf(R.id.textView2, R.id.textView3)
        var cursor = contentResolver.query(
            CallLog.Calls.CONTENT_URI!!, llamadas, CallLog.Calls.TYPE + " = ?",
            arrayOf<String>(tipo.toString()), "${CallLog.Calls.LAST_MODIFIED}"
        )
    var adapter = SimpleCursorAdapter(
        applicationContext,R.layout.row_list,cursor,datos,datosEnPantalla,0)
        lista.adapter = adapter
    }
}
